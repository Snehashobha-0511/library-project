const { Client } = require('pg');

const client = new Client({
    host: 'localhost',
    port: 5432,
    password: 'sneha0511',
    database: 'idexcel_db',
    user: 'postgres'
});

client.connect().then(success => {
    console.log('Database connected successfully');
}).catch(err => {
    console.log('Database Error', err);
});

module.exports = client;