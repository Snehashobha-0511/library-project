const express = require('express');
const router = express.Router();

const auth = require('../middlewares/auth');
const booksController = require('../controllers/books');

//Authentication code

router.get('/', booksController.getAllBooks);

router.post('/', booksController.addBooks);

router.put('/:bookid',  booksController.checkBookId, booksController.updateBooks);
//router.put('/:bookid', booksController.updateBooks);

router.delete('/:bookid',  booksController.checkBookId, booksController.deleteBooks);
//router.delete('/:bookid',  booksController.checkBookId, booksController.deleteBooks);

module.exports = router;











// const express = require('express');
// const router = express.Router();

// const auth = require('../middlewares/auth');
// const booksController = require('../controllers/book');

// //Authentication code

// router.get('/', booksController.getAllBooks);

// router.post('/', booksController.addBooks);

// router.put('/:bookid',  booksController.checkBookId, booksController.updateBooks);

// router.delete('/:bookid',  booksController.checkBookId, booksController.deleteBooks);

// module.exports = router;

