const db = require('../util/database');

const checkBookId = (req, res, next) => {
    const checkAvailability = `
        SELECT * FROM book
        WHERE bookid=${req.params.bookid}
    `;
    db.query(checkAvailability).then(dbRes => {
        if (dbRes.rows.length > 0) {
            next();
        } else {
            res.json({
                error: true,
                message: 'No book found with the ID'
            });
        }
    });
}

const getAllBooks = (req, res, next) => {
    const query = 'SELECT * FROM book';
    db.query(query).then(dbRes => {
        res.json({
            error: false,
            book: dbRes.rows
        });
    }).catch(dbErr => {
        next(dbErr);
    });
}

const addBooks = (req, res, next) => {
    const query = `
        INSERT INTO book
        VALUES (
            ${req.body.bookid},
            '${req.body.booktitle}', 
            ${req.body.categoryid}, 
            '${req.body.author}',
            ${req.body.bookcopies},
            '${req.body.bookpub}',
            '${req.body.publishername}',
            '${req.body.isbn}',
            ${req.body.copyrightyear},
            '${req.body.dateadded}',
            '${req.body.status}'
        )`;
    db.query(query).then(dbRes => {
        res.json({
            error: false,
            data: dbRes.rows
        });
    }).catch(dbErr => {
        next(dbErr);
    });
}

const updateBooks = (req, res, next) => {
    const updateQuery = `
        UPDATE book
        SET 
            booktitle='${req.body.booktitle}', 
            categoryid=${req.body.categoryid}, 
            author='${req.body.author}',
            bookcopies=${req.body.bookcopies},
            bookpub='${req.body.bookpub}',
            publishername='${req.body.publishername}',
            isbn='${req.body.isbn}',
            copyrightyear=${req.body.copyrightyear},
            dateadded='${req.body.dateadded}',
            status='${req.body.status}'
        WHERE bookid='${req.params.bookid}'
            
    `;
    db.query(updateQuery).then(dbRes => {
        res.json({
            error: false,
            message: 'Book Details updated successfully'
        });
    }).catch(dbErr => {
        next(dbErr);
    });
}

const deleteBooks = (req, res, next) => {
    const query = `
        DELETE FROM book
        WHERE bookid='${req.params.bookid}'
    `;
    db.query(query).then(dbRes => {
        res.json({
            error: false,
            message: 'Book Details Deleted Successfully'
        });
    }).catch(dbErr => {
        next(dbErr);
    });
}

module.exports = {
    checkBookId,
    getAllBooks,
    addBooks,
    updateBooks,
    deleteBooks
};