const db = require('../util/database');
//const { v4: uuidv4 } = require('uuid');

const checkEmail = (req, res, next) => {
    const checkAvailability = `
        SELECT * FROM bookborrow
        WHERE email='${req.params.email}'
    `;
    
    db.query(checkAvailability).then(dbRes => {
        if (dbRes.rows.length > 0) {
            res.json({
                error: false,
                // message: 'No book found with the ID'
                book: dbRes.rows
            });
        } else {
            res.json({
                error: true,
                message: 'No book found with the ID'
            });
        }
    });
}

const getAllBookBorrow = (req, res, next) => {
    const query = 'SELECT * FROM bookborrow';
    db.query(query).then(dbRes => {
        res.json({
            error: false,
            //book: dbRes.rows
            book_info: dbRes.rows
        });
    }).catch(dbErr => {
        next(dbErr);
    });
}

//const addBookBorrow = (req, res, next) => {
    //'${req.body.date_issued}',
    //'${req.body.status}'
const requestBookBorrow = (req, res, next) => {
    const query = `
        INSERT INTO bookborrow
        VALUES (
            '${req.body.email}',
            ${req.body.book_id},
            '${req.body.due_date}',
            'Request'
        )`;
    db.query(query).then(dbRes => {
        res.json({
            error: false
            //book_info: dbRes.rows
        });
    }).catch(dbErr => {
        next(dbErr);
    });
}

const updateBookBorrow = (req, res, next) => {
    const updateQuery = `
        UPDATE bookborrow
        SET 
            book_id=${req.body.book_id}, 
            date_issued='${req.body.date_issued}',
            due_date='${req.body.due_date}',
            status='${req.body.status}'
        WHERE email='${req.params.email}'
            
    `;
    db.query(updateQuery).then(dbRes => {
        res.json({
            error: false,
            message: 'Book details updated successfully'
        });
    }).catch(dbErr => {
        next(dbErr);
    });
}

const deleteBookBorrow = (req, res, next) => {
    const query = `
        DELETE FROM bookborrow
        WHERE email='${req.params.email}'
    `;
    db.query(query).then(dbRes => {
        res.json({
            error: false,
            message: 'Book Deleted Successfully'
        });
    }).catch(dbErr => {
        next(dbErr);
    });
}



module.exports = {
    
    checkEmail,
    getAllBookBorrow,
    requestBookBorrow,
    updateBookBorrow,
    deleteBookBorrow
};
