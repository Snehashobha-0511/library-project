//import logo from './logo.svg';
import './App.css';
import {BrowserRouter as Router,Link, Route, Switch } from 'react-router-dom';
//import {FaEnvelope, FaHome, FaPhone, FaUser} from 'react-icons/fa';
//import {FcAbout, FcLibrary} from 'react-icons/fc';

import Home from './Components/home/Home';
import ContactUs from './Components/contactUs/ContactUs';
import AboutUs from './Components/AboutUs/AboutUs';
import Signup from './Components/signup/Signup';
//import ak from './Components/signup/ak';

import AdminLogin from './Components/admin/adminLogin/AdminLogin';

import AddBooks from './Components/admin/addBooks/AddBooks';
import AddUser from './Components/admin/addUser/AddUser';
import ShowBooks from './Components/admin/showBooks/ShowBooks';
import EditBooks from './Components/admin/editBook/EditBooks';

import UserLogin from './Components/user/userLogin/UserLogin';
import BookBorrow from './Components/user/bookBorrow/BookBorrow';
import BookSearch from './Components/user/bookSearch/BookSearch';
import BookShow from './Components/user/bookShow/BookShow';

function App() {
  return (
    <div className="App">
      <Router>
        <Switch>
              <Route exact path="/" component={Home}/>
              <Route path="/home" component={Home}/>
              <Route path="/contactUs" component={ContactUs}/>
              <Route path="/aboutUs" component={AboutUs}/>
              <Route path="/signup" component={Signup}/>
              {/* <Route path="/ak" component={ak}/> */}

              <Route path="/adminLogin" component={AdminLogin}/>
              
              <Route path="/addBooks" component={AddBooks}/>
              <Route path="/addUser" component={AddUser}/>
              <Route path="/showBooks" component={ShowBooks}/> 
              <Route path="/editBooks" component={EditBooks}/> 

              <Route path="/userLogin" component={UserLogin}/>
              <Route path="/bookBorrow" component={BookBorrow}/>
              <Route path="/bookSearch" component={BookSearch}/>
              <Route path="/bookShow" component={BookShow}/> 
        </Switch>
      </Router>
</div>
);
}
export default App;

// import './App.css';
// import {BrowserRouter as Router, Link, Route, Switch } from 'react-router-dom';
// import Home from './Components/Home/Home';
// import Contact from './Components/Contact/Contact';
// import About from './Components/About/About';
// import Register from './Components/Register/Register';

// import AdminLogin from './Components/Admin/AdminLogin/AdminLogin'; 
// import AccountCreation from './Components/Admin/AccountCreation/AccountCreation';
// import AddBooks from './Components/Admin/AddBooks/AddBooks';
// import AddUser from './Components/Admin/AddUser/AddUser';

// import UserLogin from './Components/User/UserLogin/UserLogin';
// import BookBorrow from './Components/User/BookBorrow/BookBorrow';
// //import BookBorrowUser from './Components/BookBorrowUser/BookBorrowUser';
// import BookSearch from './Components/User/BookSearch/BookSearch';

// function App() {
//   return (
//           <div className="App">
   
//             <Router>        
//                 <Switch>
//                   <Route exact path="/Home" component={Home}/>
//                   <Route path="/Contact" component={Contact}/>
//                   <Route path="/About" component={About}/> 
//                   <Route path="/Register" component={Register}/> 

//                   <Route path="/AdminLogin" component={AdminLogin}/>
//                   <Route path="/AccountCreation" component={AccountCreation}/>
//                   <Route path="/AddUser" component={AddUser}/> 
//                   <Route path="/AddBooks" component={AddBooks}/> 


//                   <Route path="/UserLogin" component={UserLogin}/>
//                   <Route path="/BookBorrow" component={BookBorrow}/> 
//                   <Route path="/BookSearch" component={BookSearch}/> 
//                   {/* <Route path="/BookBorrow" component={BookBorrow}/> 
//                   <Route path="/BookBorrow" component={BookBorrow}/>  */}
//                 </Switch> 
//           </Router> 
         
//           </div>

//   );
// }

// export default App;