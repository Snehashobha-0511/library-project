import React from 'react'
import { Link } from 'react-router-dom'
import {FaHome, FaSignOutAlt, FaBookOpen} from 'react-icons/fa';
import {FcLibrary} from 'react-icons/fc';
import {FiSearch} from 'react-icons/fi';



function out(){
    // localStorage.removeItem()
   window.localStorage.removeItem("token");
   }
  
const btn ={
    
    paddingLeft: "600px",
   
  }
export default function UserNavbar() {
    return (
        <nav class="navbar navbar-expand-lg navbar-light" style={{height:"60px", backgroundColor:"PaleVioletRed"}}>
                <div class="container-fluid">
                    <Link class="navbar-brand text-white" href="#" style={{fontStyle:"italic"}}><b>Library Management System</b></Link>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                             <Link to="/home" class="nav-link active text-white"  aria-current="page" href="#"><FaHome/>Home</Link>
                            </li>
                            {/* <li class="nav-item">
                                <Link to="/bookSearch" class="nav-link  active" href="#" ><FiSearch/>Book Search</Link>
                            </li> */}
                            <li class="nav-item">
                                <Link to="/bookBorrow" class="nav-link  active text-white" href="#" ><FaBookOpen/>BookBorrow</Link>
                            </li>
                            <li class="nav-item">
                                <Link to="/bookShow" class="nav-link  active text-white" href="#" ><FiSearch/>BookShow</Link>
                            </li>
                            <li class="nav-item">
                                <Link to="/home" text-align="right" onClick={out} class="nav-link  active text-white"  href="#" tabindex="-1" aria-disabled="true" style={btn}><FaSignOutAlt/>LogOut</Link>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav> 
        
    )
}


// import React from 'react'
// import { Link } from 'react-router-dom'



// function out(){
//    // localStorage.removeItem()
//   window.localStorage.removeItem("token");
//   }
//   // onclick=
// //  window.localStorage.clear(); //clear all localstorage
//   //window.localStorage.removeItem("token"); //remove one item
// const btn ={
    
//     paddingLeft: "1300px",
   
//   }
// export default function UserNavbar() {
          
//     return (
//         <nav class="navbar navbar-expand-lg navbar-light bg-info">
//                 <div class="container-fluid">
//                     <Link class="navbar-brand" href="#">My Library</Link>
//                     <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
//                     <span class="navbar-toggler-icon"></span>
//                     </button>
//                     <div class="collapse navbar-collapse" id="navbarNav">
//                         <ul class="navbar-nav">
//                             <li class="nav-item">
//                              <Link to="/" class="nav-link active" aria-current="page" href="#">Home</Link>
//                             </li>
//                             <li class="nav-item">
//                                 <Link to="/BookSearch" class="nav-link  active" href="#" >Book Search</Link>
//                             </li>
//                             <li class="nav-item">
//                                 <Link to="/BookBorrow" class="nav-link  active" href="#" >BookBorrow</Link>
//                             </li>
//                             <li class="nav-item">
//                                 <Link to="/BookShow" class="nav-link  active" href="#" >BookShow</Link>
//                             </li>
//                             <li class="nav-item">
//                                 <Link to="/" text-align="right" class="nav-link  active" href="#" onClick={out} tabindex="-1" aria-disabled="true" style={btn} >LogOut</Link>
//                             </li>
//                         </ul>
//                     </div>
//                 </div>
//             </nav> 
        
//     )
// }
