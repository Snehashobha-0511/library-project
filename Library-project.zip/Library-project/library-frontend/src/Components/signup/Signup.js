import React, { Component } from 'react'
//import { Link } from 'react-router-dom';
import HomeNavbar from '../../navigationbar/Homenav';
//import { FormErrors } from '../Welcome/FormErrors';
import Axios from 'axios';
//import './Signup.css';

const form = {
  border:"lightgrey solid 2px",
  
  marginLeft:"230px",
  backgroundColor:"Silver",
  
}

export default class SignUp extends Component{

constructor (props) {
  super(props);

  this.onChangeName = this.onChangeName.bind(this);
  this.onChangeEmail = this.onChangeEmail.bind(this);
  this.onChangePassword = this.onChangePassword.bind(this);

  this.onSubmit = this.onSubmit.bind(this);

  this.state = {
    name: '',
    email: '',
    password: '',
  }
}

onChangeName(e) {
  this.setState({ name: e.target.value })
}

onChangeEmail(e) {
  this.setState({ email: e.target.value })
}

onChangePassword(e) {
  this.setState({ password: e.target.value})
}

onSubmit(e) {
  e.preventDefault()

  const userObject = {
    name: this.state.name,
    email: this.state.email,
    password:this.state.password
  };
  
  Axios.post('http://localhost:8080/users/register', userObject)
  .then((res) => {
      console.log(res.data)
     
      alert(' User register Successfully');
  }).catch((error) => {
      console.log(error)
  });

this.setState({ name: '',email: '',password:''})
}

 render() {
  return ( 
        <>
          <div>
            <HomeNavbar/>
          </div>
        
            <div>
                <div className="row">
                        <div className="col-10">
                            <div className="row">
                                <div className="col-2"></div>
                                <div className="col-8">
                                <div className="jumbotron mt-5" style={form}>
          <div>
            <h3 style={{textAlign:"center", marginBottom:"30px", color:"black"}}>Enter user details</h3>

            <form onSubmit={this.onSubmit} style={{width:"500px"}}>
            <div style={{marginLeft:"25px"}}>
              <div className="form-row">
                <div className="col" >
                  <label htmlFor="name">Name<span className="required text-danger">*</span></label>
                  <input type="text" required name="name" id="name" value={this.state.name} style={{backgroundColor:"white"}}
                  onChange={this.onChangeName}   className="form-control"  placeholder="enter name" />
                </div>
                </div>

                <div className="form-row" style={{marginTop:"20px"}}>
                <div className="col" >
                  <label htmlFor="email">Email <span className="required text-danger">*</span></label>
                  <input type="text" name="email" id="email" value={this.state.email} style={{backgroundColor:"white"}}
                   onChange={this.onChangeEmail} maxLength="30"   className="form-control" placeholder="enter email" />
                </div>
                </div>

                <div className="form-row" style={{marginTop:"20px"}} >
                <div className="col">
                  <label htmlFor="password">Password <span className="required text-danger ">*</span></label>
                  <input type="password" className="form-control" name="password" value={this.state.password} style={{backgroundColor:"white"}}
                  onChange={this.onChangePassword}   placeholder="enter password" id="password" />
                </div>
                </div>
                  <div className=" text-left " style={{marginTop:"15px"}}>
                      <button type="submit" className="btn btn-danger bg-danger m-2 p-2" style={{width:"150px" }}> SignUp</button>
                  </div>
              </div>
          </form>
          </div>
        </div>
      </div>
    <div className="col-2"></div>
  </div>
  </div>
  </div>        
  </div>
  </>
    
)
}
}

