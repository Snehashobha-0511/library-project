import React from 'react';
import HomeNavbar from '../../navigationbar/Homenav';

//  function AboutUs() {
     
//     return (
//         <>
//             <div>
//                 <HomeNavbar/>
//             </div>
//         <div>
//             <h1 class="cont" style={{color:"crimson", textAlign:"center", padding: "10px"}}>About Us</h1>
//             <p class="constant" style={{paddingLeft:"15px"}}>A Library management system is a software that uses to maintain the record of the library. It contains work like the number of available books in the library, the number of books are issued or returning or renewing a book or late fine charge record, etc. Library Management Systems is software that helps to maintain a database that is useful to enter new books and record books borrowed by the members, with the respective submission dates. Moreover, it also reduces the manual record burden of the librarian.</p>
                    
//           <img src="https://jgu.edu.in/wp-content/uploads/2019/03/global-library-main_0_0-1.jpg" class="card-img-top" style={{width: "1365px",
//     height:"400px"}}  alt="..."/>
//         </div>
//         </>
//     )
// }
// export default AboutUs;

const card = {
    width:"60rem",
    align:"center",
    marginLeft:"250px",
    border:"solid",
    borderColor:"Silver",
    // boxShadow: "0px 10px 40px black",
    marginTop:"50px"
  }
  
  const image ={
        height:"300px",
        width:"100%",
        marginTop:"1px",
        marginLeft:"1px"
  }

 function AboutUs() {
    return (
        <>
            <div>
                <HomeNavbar/>
            </div>
        <div>
        
         

            <div class="card" style={ card }>
            <h1 style={{backgroundColor:"Silver"}}>AboutUs:</h1>
  <img src="https://www.pixel-studios.com/blog/wp-content/uploads/2018/12/012.jpg" class="card-img-top" style={ image } alt="..."></img>
  <div class="card-body">
    <p class="card-text" style={{marginRight:"85px"}}>The Online Library Management System will provide an automated s/w for the college library to search the books online .
    This Intranet based application will provide facilities to different kinds of users, which reduces the complexities arised in the “Manual Library System “ .
    Thus it puts an option for all categories of users to have the transaction details with added security features. This integrated system allows both the user and librarian component to work independently.
    </p>

  </div>
</div>
        </div>
        </>
    )
}
export default AboutUs;