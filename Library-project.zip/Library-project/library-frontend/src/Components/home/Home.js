import React from 'react'
import './Home.css'
import {Link} from 'react-router-dom' 
import HomeNavbar from '../../navigationbar/Homenav'

export default function Home() {
    return (
  
      <>
      <div>  
      <h1  align="center" style={{background:'PaleVioletRed',color:'white',fontStyle:'Cursive',margin:'2px',padding:'2px'}}> <img src="https://www.nacc.edu/Content/Uploads/nacc.edu/images/Library/AGbook.jpg" style={{height:"40px" , width:"130px" ,borderRadius:'50%'}} height="55px" /><b><i>LIBRARY MANAGEMENT SYSTEM</i></b></h1>

        <HomeNavbar/>
      </div>
      <div>
                    
      </div>
    
      <div id="carouselExampleControls" class="carousel slide" data-ride="carousel" style={{height:"400px"}}>
      <div className="carousel-inner">
        <div className="carousel-item active">
          <img src="https://jbmatrix.com/product/librarymanagement/image/library-banner.jpg" style={{height:"600px"}} class="d-block w-100" alt="https://www.bracknell-forest.gov.uk/sites/default/files/bracknell-library-sofa-alternative-header-image.jpg"></img>
        </div>
        <div className="carousel-item">
          <img src="https://www.sciencenewsforstudents.org/wp-content/uploads/2019/11/860_main_library_bacteria.png" style={{height:"600px"}}  class="d-block w-100" alt="https://www.bracknell-forest.gov.uk/sites/default/files/bracknell-library-sofa-alternative-header-image.jpg"></img>
        </div>
        <div className="carousel-item">
          <img src="https://static.theprint.in/wp-content/uploads/2018/07/Medlibrary-e1560749065614.jpg" style={{height:"600px"}}  class="d-block w-100" alt="https://static.theprint.in/wp-content/uploads/2018/07/Medlibrary-e1560749065614.jpg"></img>
        </div>
      </div>
      <Link classN    ame="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
        <span className="carousel-control-prev-icon" aria-hidden="true"></span>
        <span className="sr-only">Previous</span>
      </Link>
      <Link className="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
        <span className="carousel-control-next-icon" aria-hidden="true"></span>
        <span className="sr-only">Next</span>
      </Link>
    </div>
     
     {/* <div className="card" style={{width: "35rem"}}>
            <img src="https://www.vrsiddhartha.ac.in/wp-content/uploads/2019/09/NANI3506-1024x683.jpg" class="card-img-top" alt="..."/>
            <div class="card-body">
            <p style={{color:"black"}} class="card-text"><b></b><br/>College Library</p>
        </div>
        </div>

        <div className="card" style={{width: "35rem"}}>
            <img src="https://static.theprint.in/wp-content/uploads/2018/07/Medlibrary-e1530626526256-696x350.jpg" class="card-img-top" alt="..."/>
            <div class="card-body">
            <p style={{color:"black"}} class="card-text"><b></b><br/>Public Library</p>
        </div> 
        </div> */}

    
    
   </>
    )
}

