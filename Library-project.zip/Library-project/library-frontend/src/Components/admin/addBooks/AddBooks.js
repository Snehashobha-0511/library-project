import React, { Component } from 'react';
import Axios from 'axios';
import AdminNavbar from '../../../navigationbar/Adminnav';
//import { Link } from 'react-router-dom'
import axiosInstance from '../../../Inter/Interceptor';

const form = {
    border:"lightgrey solid 2px",
    align:"center",
    backgroundColor:"Silver",

}

export default class AddBooks extends Component {

  
    constructor(props) {
      super(props)
  
      this.onChangeBookId = this.onChangeBookId.bind(this);
      this.onChangeBookTitle = this.onChangeBookTitle.bind(this);
      this.onChangeCategoryId = this.onChangeCategoryId.bind(this);
      this.onChangeAuthor = this.onChangeAuthor.bind(this);
      this.onChangeBookCopies = this.onChangeBookCopies.bind(this);
      this.onChangeBookPub = this.onChangeBookPub.bind(this);
      this.onChangePublisherName = this.onChangePublisherName.bind(this);
      this.onChangeIsbn = this.onChangeIsbn.bind(this);
      this.onChangeCopyrightYear = this.onChangeCopyrightYear.bind(this);
      this.onChangeDateAdded = this.onChangeDateAdded.bind(this);
     
      this.onChangeStatus = this.onChangeStatus.bind(this);
  
      this.onSubmit = this.onSubmit.bind(this);
      this.state = {
        bookid: '',booktitle:'',categoryid:'',author: '', bookcopies:'',bookpub:'', publishername:'', isbn:'', copyrightyear:'', dateadded:'', status:''
      }     
  }

onChangeBookId(e) {
    this.setState({ bookid: e.target.value })
}
onChangeBookTitle(e) {
    this.setState({ booktitle: e.target.value })
}
onChangeCategoryId(e) {
    this.setState({ categoryid: e.target.value })
}
onChangeAuthor(e) {
    this.setState({ author: e.target.value })
}

onChangeBookCopies(e) {
    this.setState({ bookcopies: e.target.value})
} 
onChangeBookPub(e) {
    this.setState({ bookpub: e.target.value})
} 
onChangePublisherName(e) {
    this.setState({ publishername: e.target.value})
} 
onChangeIsbn(e){
    this.setState({ isbn: e.target.value})
}
onChangeCopyrightYear(e) {
    this.setState({ copyrightyear: e.target.value})
} 

onChangeDateAdded(e) {
    this.setState({ dateadded: e.target.value})
} 


onChangeStatus(e) {
    this.setState({ status: e.target.value})
} 

onSubmit(e) {
    e.preventDefault()

    const userObject = {
      bookid: this.state.bookid ,
      booktitle: this.state.booktitle,
      categoryid: this.state.categoryid,
      author: this.state.author, 
      bookcopies: this.state.bookcopies,
      bookpub: this.state.bookpub, 
      publishername: this.state.publishername,
      isbn: this.state.isbn, 
      copyrightyear: this.state.copyrightyear,
      dateadded: this.state.dateadded,  
      status: this.state.status
    };
   
        axiosInstance().post('books/addBooks', userObject)
        .then((res) => {
          
            alert('Book details added Successfully');
        }).catch((error) => {
            console.log(error)
        });
        this.props.history.push('/showBooks')
    this.setState({ bookid: '',booktitle:'',categoryid:'',author: '', bookcopies:'',bookpub:'', publishername:'', isbn:'', copyrightyear:'',dateadded:'',  status:''})
}   


render()
{
    return (
	<>
		<div><AdminNavbar/></div>
        <div>
            <div className="row"> 
                <div className="col-10">
                    <div className="row">
                        <div className="col-2">
						</div>
                        <div className="col-10">
                        <div className="jumbotron mt-5" style={form}>
        				<div >
        					<h3 style={{textAlign:"center", marginBottom:"30px", color:"black"}}>Add your book details Here....</h3>
                            <form onSubmit={this.onSubmit} >
                                	<div className="form-row">
                                    	<div className="col">
                                        <label htmlFor="bookId">Book Id<span className="required text-danger">*</span></label>
                                        <input type="number" required name="bookid" id="bookId" value={this.state.bookid} onChange={this.onChangeBookId}  
                                         className="form-control" style={{backgroundColor:"white"}}/>
                                    	</div>

                                    	<div className="col">
                                        <label htmlFor="categoryId">Category Id<span className="required text-danger">*</span></label>
                                        <input type="number" required name="categoryid" id="categoryId"  value={this.state.categoryid} onChange={this.onChangeCategoryId} 
                                        className="form-control" style={{backgroundColor:"white"}} />
                                    	</div>
                                        <br></br>
                                    	<div className="col">
                                        <label htmlFor="bookTitle">Book Title<span className="required text-danger">*</span></label>
                                        <input type="text" required name="booktitle" id="bookTitle" value={this.state.booktitle} onChange={this.onChangeBookTitle}   
                                        className="form-control" style={{backgroundColor:"white"}}/>
                                    	</div>
                                        
                                    	<div className="col">
                                        <label htmlFor="author">Author<span className="required text-danger">*</span></label>
                                        <input type="text" required name="author" id="author" value={this.state.author} onChange={this.onChangeAuthor}   
                                        className="form-control" style={{backgroundColor:"white"}}/>
                                        </div>
                                    </div>
                                    
                                    <div className="form-row">
                                        <div className="col">
                                        <label htmlFor="bookCopies">Book Copies<span className="required text-danger">*</span></label>
                                        <input type="number" required name="bookcopies" style={{backgroundColor:"white"}} id="bookCopies" value={this.state.bookcopies} onChange={this.onChangeBookCopies}   className="form-control" />
                                        </div>

                                        <div className="col">
                                        <label htmlFor="bookPub">Book Pub<span className="required text-danger">*</span></label>
                                        <input type="text" required name="bookpub" style={{backgroundColor:"white"}} id="bookPub" value={this.state.bookpub} onChange={this.onChangeBookPub}   className="form-control" />
                                        </div>

                                        <div className="col">
                                        <label htmlFor="publisherName">Publisher Name<span className="required text-danger">*</span></label>
                                        <input type="text" required name="publishername" style={{backgroundColor:"white"}} id="publisherName" value={this.state.publishername} onChange={this.onChangePublisherName}   className="form-control" />
                                        </div>

                                        <div className="col">
                                        <label htmlFor="isbn">Isbn<span className="required text-danger">*</span></label>
                                        <input type="text" required name="isbn" id="isbn" style={{backgroundColor:"white"}} value={this.state.isbn} onChange={this.onChangeIsbn}   className="form-control" />
                                        </div>
									</div>
									<div className="form-row">
                                        <div className="col">
                                        <label htmlFor="copyrightYear">Copyright Year<span className="required text-danger">*</span></label>
                                        <input type="number" required name="copyrightyear" style={{backgroundColor:"white"}} id="copyrightYear" value={this.state.copyrightyear} onChange={this.onChangeCopyrightYear}   className="form-control" />
                                        </div>

                                        <div className="col">
                                        <label htmlFor="dateAdded">Date Added<span className="required text-danger">*</span></label>
                                        <input type="date" required name="dateadded" style={{backgroundColor:"white"}} id="dateAdded" value={this.state.dateadded} onChange={this.onChangeDateAdded}   className="form-control" />
                                        </div>

                                        <div className="col">
                                        <label htmlFor="status">Status<span className="required text-danger">*</span></label>
                                        <input type="text" required name="status"  style={{backgroundColor:"white"}} id="status" value={this.state.status} onChange={this.onChangeStatus}   className="form-control" />
                                        </div>
                                        
                                    </div>
                                    <div className=" text-left " style={{marginTop:"5px"}}>
                                        <button type="submit" className="btn btn-danger bg-danger m-2 p-2 " style={{width:"100px"}}> AddBook</button>
                                           
                                    </div>
                            </form>
      					</div>
                    </div>
                </div>
                <div className="col-2">
				</div>
            </div>
        </div>
    </div>        
    </div>
	</>
)
}
}





























//import React from 'react';
//import './AddBooks.css'

//import{Link} from 'react-router-dom';
//import AdminNavbar from '../../../navigationbar/Adminnav';

// export default function AddBooks() {
//     return (
//         <>
// 			<div>
// 				<AdminNavbar/>
// 			</div>
//             <div>
// 				<table class="table table-hover">
// 					<thead class="table table-hover">
// 						<tr>
// 							<th scope="col">ACC NO.</th>
// 							<th scope="col">BOOK TITLE</th>
// 							<th scope="col">CATEGORY</th>
// 							<th scope="col">AUTHOR</th>
// 							<th scope="col">COPIES</th>
// 							<th scope="col">BOOK PUB</th>
// 							<th scope="col">PUBLISHER NAME</th>
// 							<th scope="col">ISBN</th>
// 							<th scope="col">COPYRIGHT YEAR</th>
// 							<th scope="col">DATE ADDED</th>
// 							<th scope="col">STATUS</th>
// 							<th scope="col">ACTION</th>
// 						</tr>
// 					</thead>
// 					<tbody>  
// 						<tr>
// 							<th scope="row">1</th>
// 							<td>Forgotten Mysteries of the sun Goddess</td>
// 							<td>Fantacy</td>
// 							<td>Lewis Bradley</td>
// 							<td>11</td>
// 							<td></td>
// 							<td>Little,Brown Book Group</td>
// 							<td>978-0-23-073483-8</td>
// 							<td>1975</td>
// 							<td>2014-11-09 06:34:27</td>
// 							<td>New</td>
// 							<td>
// 							<input type="checkbox" id="add" name="add" value="add"/>
// 							</td>
// 						</tr>
// 						<tr>
// 							<th scope="row">2</th>
// 							<td>Symbols Strength of the Religions</td>
// 							<td>Literary</td>
// 							<td>Ben Puckette</td>
// 							<td>20</td>
// 							<td></td>
// 							<td>New Holland</td>
// 							<td>978-0-23-053355-4</td>
// 							<td>2008</td>
// 							<td>2013-12-11 06:16:23</td>
// 							<td>Old</td>
// 							<td>
// 							<input type="checkbox" id="add" name="add" value="add"/>
// 							</td>
// 						</tr>
// 						<tr>
// 							<th scope="row">3</th>
// 							<td>Guide to Herbalism</td>
// 							<td>Classics</td>
// 							<td>Doris Bunn</td>
// 							<td>22</td>
// 							<td></td>
// 							<td>Blackwell Science</td>
// 							<td>978-0-23-040156-3</td>
// 							<td>2006</td>
// 							<td>2011-06-28 03:52:27</td>
// 							<td>Archive</td>
// 							<td>
// 							<input type="checkbox" id="add" name="add" value="add"/>
// 							</td>
// 						</tr>
// 						<tr>
// 							<th scope="row">4</th>
// 							<td>Trade of Choas lands</td>
// 							<td>Religious</td>
// 							<td>Allan Nguyen</td>
// 							<td>19</td>
// 							<td></td>
// 							<td>Basil Blackwell</td>
// 							<td>978-0-23-040160-0</td>
// 							<td>2004</td>
// 							<td>2019-09-23 12:47:42</td>
// 							<td>Damage</td>
// 							<td>
// 							<input type="checkbox" id="add" name="add" value="add"/>
// 							</td>
// 						</tr>
// 						<tr>
// 							<th scope="row">5</th>
// 							<td>Forbidden Evocation Strictures</td>
// 							<td>Action and Adventure</td>
// 							<td>Stephanie Home</td>
// 							<td>14</td>
// 							<td></td>
// 							<td>Hodder Gibson</td>
// 							<td>978-0-23-072745-8</td>
// 							<td>1956</td>
// 							<td>2013-12-11 11:03:452</td>
// 							<td>New</td>
// 							<td>
// 							<input type="checkbox" id="add" name="add" value="add"/>
// 							</td>
// 						</tr>
// 					</tbody>
// 				</table>
//             </div>
//         </>
//     )
// }





