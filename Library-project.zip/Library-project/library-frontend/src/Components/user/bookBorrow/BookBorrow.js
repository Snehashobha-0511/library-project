import React, { Component } from 'react'
//import { Link } from 'react-router-dom';
import UserNavbar from '../../../navigationbar/Usernav';
import axiosInstance from '../../../Inter/Interceptor';
import jwtDecode from "jwt-decode";

const tab = {
    backgroundColor:"Crimson",
    marginTop:"10px"
}

export default class ShowBooks extends Component {

    constructor(props) {
        super(props);
        this.state = { booksCollection: [] ,books:[], booksCount:0} ;
        // this.state = {books:[]};
        // this.state={booksCount:0};
        this.deleteBook = this.deleteBook.bind(this);
    }
    login() 
    {
        //console.log("ok");
        axiosInstance().post('/users/login',{
          email: this.state.email,
          password:this.state.password
        })
            .then(res => {
              //console.log("success");
                if(res.data.token){
                 // localStorage.setItem("token",res.data.token);
                 // window.location.href='http://localhost:3000/BookBorrow';
                 //this.props.history.push('/BookBorrow');
                }
               
            })
            .catch(function (error) {
              //console.log("failed");
              alert(" Failed ,Invalid Login, Please try again.");
                console.log(error);
            })
      };
      
    deleteBook = (bookid) => {
        if (window.confirm('Are you sure to delete this record?')) {
            axiosInstance().delete('/books/'+ bookid)
        .then((res) => {
            console.log('Book successfully deleted!')
            alert('Deleted succesfully')
            this.setState({
                booksCollection: this.state.booksCollection.filter( remove => remove.bookid !== bookid)
            })
        }).catch((error) => {
            console.log(error)
        })
    }}
    componentDidMount() {
        //console.log("Component Mounted");
        axiosInstance().get('/books/allBooks')
            .then(res => {
               // console.log("res",res.data);
                this.setState({ booksCollection: res.data.book_info });
            })
            .catch(function (error) {
                console.log(error);
            })
    }
    bookSelected(e,id){
        //console.log('Event', e);
        if(this.state.booksCount >= 3 && e){
            alert("Maximum Limit Exceeded");
        }
        else if(e){
            this.state.books.push(id);
            //console.log(id);
            const bookid=id;
           // const a[...x]=id;
            console.log(bookid);
            this.state.booksCount++;
            this.setState(this.state);
        }
        else{
            this.state.booksCount--;
            this.state.books.filter(x=> x!=id);
            this.setState(this.state);
            e=false;
        }
    }

    
    render() {
    return (
        <>
        <div >
            <UserNavbar/>
        </div>
             <div className="row p-10">
                    <div className="col-10">
                        <div className="row">
                             <div className="col-2" >
                                    <div className="col-1">
                                     {/* side bar */}
                                    <div className="col-10" style={{marginTop:"100px", marginLeft:"80px"}}>
                                        <form style={{marginTop:"15px", width:"180px"}}  >
                                            <div class="form-row ">
                                            <label for="exampleFormControlSelect1">Borrower name</label>
                                            <select class="form-control" id="exampleFormControlSelect1">
                                                <option>1</option>
                                            </select>
                                            </div>
                                        
                                            <div class="form-row ">
                                            <label for="exampleFormControlInput1">Due date</label>
                                            <input type="date" class="form-control" id="exampleFormControlInput1" />
                                            </div>
                                            <div class="form-row " style={{marginTop:"10px"}}>
                                            <button type="submit" class="btn btn-danger bg-danger">Borrow</button>
                                            </div>
                                        </form>
                                    </div>
            </div>
                            </div> 
                            <div className="col-10" >
                            <h2 className="text-center text-dark" style={{marginLeft:"250px", marginTop:"50px"}}>Request for your books</h2>
                            
                            
                            <table class="table table-hover table-bordered table-info table-condensed mt-3" style={{marginLeft:"150px"}}>
                                    <thead class="thead-info table-hover" style={{textAlign:"center", backgroundColor:"DarkSalmon"}}>
                                    <tr>
                                        <th scope="col">Id</th>
                                        <th scope="col">Book title</th>
                                        <th scope="col">Category</th>
                                        <th scope="col">Author</th>
                                        <th scope="col">Publisher name</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Action</th>
						            </tr>
                                    </thead>
                                    <tbody style={{textAlign:"center", backgroundColor:"white"}} >
                                   
                                        {this.state.booksCollection?.map(book => (
                                            <tr>
                                                <td>
                                                    {book.bookid}  
                                                </td>
                                                 <td>
                                                    {book.booktitle}
                                                </td> 
                                                <td>
                                                    {book.categoryid}
                                                </td>
                                                <td>
                                                    {book.author}
                                                </td>
                                              
                                                <td>
                                                    {book.publishername}
                                                </td>
                                               
                                                <td>
                                                    {book.status}
                                                </td>
                                                <td>
												<input type="checkbox" onChange={e=>this.bookSelected(e.target.value, book.bookid)}/>
                                                </td>
                                                
                                            </tr>
                                        )
                                        )
                                        }

                                    </tbody>
                            </table>

                            </div>
                        </div>
                    </div>
              </div>          
        </>
    )
}
}