import axios from "axios";

export default () => {
  const baseURL = 'http://localhost:8080';
  let headers = {};

  if (localStorage.token) {
    headers.Authorization = `Bearer ${localStorage.token}`;
    
  }
  
  const axiosInstance = axios.create({
    baseURL: baseURL,
    headers,
  });

  axiosInstance.interceptors.response.use(
    (response) =>
      new Promise((resolve, reject) => {
        resolve(response);
      }),
    (error) => {
      if (!error.response) {
        return new Promise((resolve, reject) => {
          reject(error);
        });
      }

      if (error.response.status === 403) {
        localStorage.removeItem("token");
        // Unauth logic
        // redirect to login
      } else {
        return new Promise((resolve, reject) => {
            this.props.history.push('/adminLogin');
          reject(error);
        });
      }
    }
  );

  return axiosInstance;
};

